# Nodejs sqlite SQL injection demo

Simple, isolated demo of SQL injection using sqlite with nodejs.

```npm install```, run ```npm start``` to start the server, and navigate to ```localhost:1337```.